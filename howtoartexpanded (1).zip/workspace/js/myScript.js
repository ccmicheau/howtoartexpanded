/* global $*/
$(document).ready(function(){
    $(".slide-box").click(function(){
        $(this).effect('explode',{pieces:18},'fast');

$('#slide').click(function(){
    $('.slide-box').effect('slide',
    {direction:'right'}, 'slow');
});

});

$("artsupplies").mouseover(function(){
    $(this).effect('explode', {pieces:18},'slow');

});

$('#show-text').click(function(){
    $('#hidden-text').toggleClass('hidden');

});

$('#show-text').click(function(){
    $('#hidden-text').fadeToggle('slow');
});
});
